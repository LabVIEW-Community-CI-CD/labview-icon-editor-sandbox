This is a simulated source distribution artifact.
